# I wrote this IRSSI script because I got sick of remembering which of my
# meat space friends mapped to which stupid nicks in IRC.  So that they 
# couldn't evade my mappings I also track nick changes.  Here's an example
# session:
# 
# <Ry4an> dopp, who are you again?
# <dopp> Gabe
# /call dopp Gabe                              <-- command I issue locally
# <Gabe(dopp)> I can't beleive you can't remember that.
#  (!) dopp is now known as joe
# <Gabe(joe)> I bet you're extra confused now.
# <Ry4an> Not so much.
#
# These are a ton of things I could do to make this script better.  Just off
# the top of my head are:
# - munge private messages and notices in addition to public messages
# - persistance
# - add a way to remove mappings  (I wonder if "/call a a" would work)
# - use Irssi's expando mechanism to safely do nick rewriting (ala showmodes.pl)
# 
# I will almost certainly never get around to doing any of those.

use Irssi;
use strict;
use vars qw($VERSION %IRSSI %MAP);

$VERSION = "1.0";
%IRSSI = (
	authors     => "Ry4an Brase",
	contact     => 'ry4an-irssi@ry4an.org',
	name        => "NickTrack",
	description => "Hides nickname switching tomfoolery",
	license     => "public domain",
	url         => "http://ry4an.org",
	changed     => "Fri Oct  3 18:15:21 CDT 2003",
);

sub call_cmd {
    my ($data, $server, $witem) = @_;
    my ($left, $right) = split ' ', $data;
    unless (defined $left && defined $right) {
        print "Usage: /call theirnick yournameforthem";
        return;
    }
    $MAP{$left} = $right;
    print "$left will now be known as $right";
};

Irssi::command_bind call => \&call_cmd;

sub rewrite {
    my ($server, $data, $nick, $mask, $target) = @_;
    if (defined $MAP{$nick}) {
        $nick = "$MAP{$nick}($nick)";
    }
    Irssi::signal_continue($server, $data, $nick, $mask, $target);
}

sub nick_change {
    my ($chan, $nick_rec, $old_nick) = @_;
    my $nick = $nick_rec->{'nick'};
    if (defined $MAP{$old_nick}) {
        $MAP{$nick} = $MAP{$old_nick};
    } else {
        $MAP{$nick} = $old_nick;
    }
}

Irssi::signal_add("message public", \&rewrite);
Irssi::signal_add("nicklist changed", \&nick_change);

#!/bin/sh
umask 002
perl -n -e ';' /dev/null   # discard any stdin from procmail
cd /home/ry4an/html/unblog
/usr/local/bin/mhonarc -quiet -rcfile ry4an.mrc /home/mailman/archives/private/unblog.mbox/unblog.mbox
cd /home/ry4an/html/unblog/blog
/usr/local/bin/mhonarc -quiet -rcfile blog.mrc /home/mailman/archives/private/unblog.mbox/unblog.mbox
cd /home/ry4an/html/unblog
./makerss.pl < blog/rss.shtml > rss.xml

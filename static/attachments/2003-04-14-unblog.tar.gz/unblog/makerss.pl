#!/usr/bin/perl -w

use strict;

my $line;

while (<>) {
    $line = $_;
    unless ($line =~ /--#include file="(\S+)" --/) {
        print $line;
        next;
    }
    open INLINE, "<$1" || print "COULDN'T OPEN $1: $!";
    while (<INLINE>) {
        next if /^\s*<!--/;
        s[href="(\w+\d\d\d\d\d\.\w+)"\s*><tt>]
            [href="http://ry4an.org/unblog/$1"><tt>]g;
        s/&/&amp;/g;
        s/</&lt;/g;
        s/>/&gt;/g;
        print;
    }
}

#!/bin/sh

# this is a crappy way to do this
/home/ry4an/html/unblog/clean.sh  > /dev/null # delete everything
/home/ry4an/html/unblog/update.sh  # full rebuild
exit                               # before we go do it right

# this is how it should be done, but it doesn't work because replies which
# don't show up in the blog don't get saved in the blog's db, and thus message
# numbers get re-used

# this re-cat's the email out so it can be used in a filter chain
umask 002
cd /home/ry4an/html/unblog
perl -p -e 'last if /^_{47}$/;' > $$.tmp  #toss out mailman sig
/usr/local/bin/mhonarc -quiet -rcfile ry4an.mrc -add < $$.tmp
cd /home/ry4an/html/unblog/blog
/usr/local/bin/mhonarc -quiet -rcfile blog.mrc -add < ../$$.tmp
cd /home/ry4an/html/unblog
./makerss.pl < blog/rss.shtml > rss.xml
cat $$.tmp
rm $$.tmp

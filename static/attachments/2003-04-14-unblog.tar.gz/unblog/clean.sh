#!/bin/sh
cd /home/ry4an/html/unblog
rm -f -v jpg00*.jpg bin00*.bin pl00*.pl msg00*.html png00*.png gif00*.gif .mhonarc.db threads.html maillist.html rss.xml gz00*.gz
cd /home/ry4an/html/unblog/blog
rm -f -v jpg00*.jpg bin00*.bin pl00*.pl msg00*.html png00*.png gif00*.gif .mhonarc.db rss.shtml index.shtml gz00*.gz

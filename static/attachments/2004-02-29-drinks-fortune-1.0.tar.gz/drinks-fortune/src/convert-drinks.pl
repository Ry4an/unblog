#!/usr/bin/perl -w

# Written by Ry4an Brase http://ry4an.org
# Released into public domain Sun Feb 29 17:51:04 CST 2004
#
# run as:          ./convert-drinks.pl drinks.cvs > drinks
# follows with:    strfile drinks

use strict;

my ($title, $ingredients, $glass, $instructions);
while (<>) {
    chomp;
    ($title, $ingredients, $glass, $instructions) = split ':', $_;
    my @ingredients = split ',', $ingredients;

    print "$title (serve in $glass)\n";
    foreach my $ingredient (@ingredients) {
        print "    $ingredient\n";
    }
    write STDOUT;
    print "%\n";
}

format STDOUT =
Instructions: ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$instructions
~~  ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
$instructions
.

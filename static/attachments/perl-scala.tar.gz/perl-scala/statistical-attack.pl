#!/usr/bin/perl -w

use strict;

my $target = shift || die "Usage: ./$0 r0\n";

my @recipientsRoundsTargetSent = ();
my @messagesTargetSentPerRound = (); # only rounds where s/he did send
my @recipientsRoundsTargetNotSent = ();
my $roundSize; # b  (always 32, but why hardcode)

my $targetSentCount; # number of messags sent by target this round
while (<>) {
    my ($role, $who);
    unless (($role, $who) = /^([SR]).* \[(.*)\]/) {
        die "Unparseable line '$_'\n";
    }
    my @people = split ",", $who;
    $roundSize = @people;
    if ($role eq "S") {
        $targetSentCount = grep($_ eq $target, @people);
        next; # move on to the receive
    }
    if ($targetSentCount) {  # target sent a message this round
        push @recipientsRoundsTargetSent, \@people;
        push @messagesTargetSentPerRound, $targetSentCount;
    } else { # target sent no message this round
        push @recipientsRoundsTargetNotSent, \@people;
    }
}

# background distribution from rounds where target didn't send
my @background = ((0) x (&nameToIndex("z9")+1));
foreach my $ref (@recipientsRoundsTargetNotSent) {
    map {$background[&nameToIndex($_)]++} @{$ref};
}
# divide by b and by t' to get U
map {$_ /= ($roundSize * @recipientsRoundsTargetNotSent)} @background;

# target recipient distribution from rounds where target did send
my @probability = ((0) x (&nameToIndex("z9")+1)); # sum of o sub i (before / b)
my $messagesTargetSentTotal = 0;
foreach my $index (0 .. $#messagesTargetSentPerRound) {
    my @recipients = @{$recipientsRoundsTargetSent[$index]};
    my $messagesTargetSentThisRound = $messagesTargetSentPerRound[$index];
    $messagesTargetSentTotal += $messagesTargetSentThisRound;
    map {$probability[&nameToIndex($_)] += $messagesTargetSentThisRound}
        @recipients;
}
# divide by b and by t to get O
map {$_ /= ($roundSize * @recipientsRoundsTargetSent)} @probability;

# m overbar = mean(@messagesTargetSentPerRound)
my $messagesTargetSentPerSendingRoundAvg
    = $messagesTargetSentTotal / @recipientsRoundsTargetSent;

# build up the final vector v
my @result = map {
    ($_ * -1 * ($roundSize - $messagesTargetSentPerSendingRoundAvg)
     + ($roundSize * shift @probability))
    / $messagesTargetSentPerSendingRoundAvg } @background;

my $index = 0;
map { printf "%03d %s %1.5f\n", ($index, &indexToName($index++), $_) } @result;

######################## subroutines #######################
sub nameToIndex {
    my @ords = unpack("W*", $_[0]);
    26 * ($ords[1] - ord('0')) + $ords[0] - ord('a');
}
sub indexToName {
    chr($_[0] % 26 + ord('a')) . chr($_[0] / 26 + ord('0'));
}

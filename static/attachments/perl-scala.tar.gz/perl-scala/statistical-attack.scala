#!/bin/sh
exec scala $0 $@
!#

// conversion stuff
def nameToIndex(name: String) : Int = {
  (name.charAt(1) - '0') * 26 + name.charAt(0) - 'a'
}
def indexToName(index: Int) : String = {
  (index % 26 + 'a').toChar.toString ++ (index / 26 + '0').toChar.toString
}

val target = nameToIndex(args(0))

val RawRow = """^([SR]).* \[(.*)\]""".r

// read in the file and transform to tuples of target-sent-count and
// lists-of-recipients split into list of rounds target sent and ones
// where s/he didn't
val (targetSent, targetNotSent) = scala.io.Source.fromFile("rounds.txt")
  .getLines
  .map { case RawRow(_,who) => who.split(",").map(nameToIndex).toList }
  .grouped(2)
  .map { case List(send,recv) => (send.count(_ == target), recv) }
  .toList
  .partition(_._1 > 0)

// background distribution from rounds where target didn't send
val background = for (a <- targetNotSent.map(_._2)
    .flatten
    .groupBy(identity)) yield
  (a._1, 1.0d * a._2.length / 32 / targetNotSent.length)

// recipient totals from rounds where target did send
val probability = for (a <- targetSent
    .flatMap { case (n,a) => List.fill(n)(a) }
    .flatten
    .groupBy(identity)) yield
  (a._1, 1.0d * a._2.length / 32 / targetSent.length)

val messagesTargetSentPerSendingRoundAvg
  = targetSent.map(_._1).reduceLeft(_ + _) / targetSent.length


val result = Range(nameToIndex("a0"), nameToIndex("z9")).toList
  .map(index => (index, (background.getOrElse(index, 0.0)
    * -1.0d * (32.0d - messagesTargetSentPerSendingRoundAvg)
    + (32.0d * probability.getOrElse(index, 0.0)))
    / messagesTargetSentPerSendingRoundAvg))

for ((i,r) <- result) {
  println("%03d %s %1.5f".format(i, indexToName(i), r))
}

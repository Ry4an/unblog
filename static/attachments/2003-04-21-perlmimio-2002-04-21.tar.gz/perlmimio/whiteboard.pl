#!/usr/bin/perl -w

# This software is (c) Copyright 2003 Ry4an Brase <ry4an@ry4an.org>.  It is
# distributable under the terms of the Artistic License
# http://opensource.org/licenses/artistic-license.php
#
# Usual usage:  mimioparse.pl | whiteboard.pl

use GD;
use Date::Format;
use strict;

########################################################
###### THINGS WORTH TWEAKING ###########################

my $dataDir = $ENV{'HOME'} . "/projects/mimio/data";
my $width = 640;
my $height = 480;

my $bigEraserRadius = 100; my $smallEraserRadius = 50;  # measured in pixels

my @backgroundColorRgb = (255, 255, 255); # white

my $leftX = 0;     # had to find these experimentally, they vary by whiteboard
my $rightX = 83;   # To find them just press the pen to the whiteboard in the
my $topY = 0;      # top-left and bottom-right corners and record the MARKs
my $bottomY = -51; # produced by mimioparse.pl

# this must return immediately, no fork is done. $file becomes filepath/name
my $imageViewer = q"mozilla -remote 'openurl(file://$file)'";

########################################################
###### THINGS YOU MIGHT WANT TO TWIDDLE ################

my $DEBUG = 0;     # makes things loud

my $ORDER = 4;  # number of derrivitives to take when filtering points
# ALT my @threshold = (0, @ARGV); # length = $ORDER + 1
my @threshold = (0,8,11,14,18); # length = $ORDER + 1, arrived at by expirment

# these control the actions of the buttons
sub button_new { # clear the page and start a new graphic
    &savePage;
    &newPage;
}
sub button_tag { # make an image snapshot on disk
    &savePage;
}
sub button_print { # make an on disk image snapshot and view it on screen
    my $file = &savePage;
    my $cmd = $imageViewer;
    $cmd =~ s/\$file/$file/g;
    system $cmd;
}
sub button_maximize { # does nothing
    print "Maximize is un-implemented.\n";
}
sub button_calculator { # exits
    &savePage;
    print "Exiting.\n";
    exit;
}
########################################################
###### END CONFIGURATION AREA ##########################

my %brushes = ('BIGERASE' => &getEraser($bigEraserRadius),
            'SMALLERASE' => &getEraser($smallEraserRadius));
my %pens = ('BIGERASE' => gdBrushed, 'SMALLERASE' => gdBrushed); # colors later

my %buttons = ( 'NEW' => \&button_new,
                'TAG' => \&button_tag,
                'PRINT' => \&button_print,
                'MAXIMIZE' => \&button_maximize,
                'CALCULATOR' => \&button_calculator);

my $curPen;
my $board;
my $sessionDir;
my $curShot;
my $curPage = 0;  # incremented by newPage

my @oldX;  # for derrivatives
my @oldY;
my @curX;
my @curY;

&newPage; # start logging

# the main listening loop
while (<STDIN>) {
    my @args = split / /;
    chomp $args[-1];
    my $cmd = shift @args;

    if ($cmd eq 'BUTTON') {
        my $name = shift @args;
        unless (defined $buttons{$name}) {
            print STDERR "Warning unrecognized button: $name\n";
            next;
        }
        &{$buttons{$name}};
        next;
    }
    print LOGFILE;  # don't log button presses
    if ($cmd eq 'MARKERSTART') {
        my $pen = shift @args;
        unless (defined $pens{$pen}) {
            print STDERR "Warning unrecognized pen: $pen\n";
            next;
        }
        $curPen = $pen;
        if (defined $brushes{$curPen}) {
            $board->setBrush($brushes{$curPen});
        }
        @oldX = (); @oldY = (); # clear them
        next;
    }
    if ($cmd eq 'MARKEXTEND') {
        my $pen = $args[2];
        if ($pen ne $curPen) {
            print STDERR "Warning: pen changed unexpectedly: $pen\n";
        }
        # fall through
    }
    if ($cmd eq 'MARK') {
        ($curX[0], $curY[0]) = &translate(@args);
        print "Before:\n" if $DEBUG;
        print "\tOldX=[" . (join ",", @oldX) . "]\n" if $DEBUG;
        print "\tCurX=[" . (join ",", @curX) . "]\n" if $DEBUG;
        print "\tOldY=[" . (join ",", @oldY) . "]\n" if $DEBUG;
        print "\tCurY=[" . (join ",", @curY) . "]\n" if $DEBUG;
        if (! (@curX = &derrivative(\@oldX, \@curX))
                || ! (@curY = &derrivative(\@oldY, \@curY))) {
            print "Discarding:\n" if $DEBUG;
            print "\tOldX=[" . (join ",", @oldX) . "]\n" if $DEBUG;
            print "\tCurX=[" . (join ",", @curX) . "]\n" if $DEBUG;
            print "\tOldY=[" . (join ",", @oldY) . "]\n" if $DEBUG;
            print "\tCurY=[" . (join ",", @curY) . "]\n" if $DEBUG;
            next;
        }
        if (defined $oldX[0] && defined $oldY[0]) {
            $board->line($oldX[0],$oldY[0],$curX[0],$curY[0], $pens{$curPen});
        }
        @oldX = @curX;
        @oldY = @curY;
        @curX = ();
        @curY = ();
        print "After:\n" if $DEBUG;
        print "\tOldX=[" . (join ",", @oldX) . "]\n" if $DEBUG;
        print "\tCurX=[" . (join ",", @curX) . "]\n" if $DEBUG;
        print "\tOldY=[" . (join ",", @oldY) . "]\n" if $DEBUG;
        print "\tCurY=[" . (join ",", @curY) . "]\n" if $DEBUG;
        next;
    }
    if ($cmd eq 'MARKEND') {
        $curPen = undef;
        next;
    }
}

##########################[ subroutines ]##########################

# takes array ref to old and new values.  returns empty list if exceeds
# thresholds
sub derrivative {
    my $oldRef = shift;
    my $curRef = shift;
    my @old = @{$oldRef};
    my @cur = @{$curRef};
    print "Inside Before:\n" if $DEBUG;
    print "\tOld=[" . (join ",", @old) . "]\n" if $DEBUG;
    print "\tCur=[" . (join ",", @cur) . "]\n" if $DEBUG;

    foreach my $order (1 .. $ORDER) {
        unless (defined $old[$order-1]) {
            last;
        }
        $cur[$order] = $cur[$order-1] - $old[$order-1];
        print "Set \$cur[\$order] to $cur[$order]\n" if $DEBUG;
        if ($threshold[$order]
                && (abs($cur[$order]) > $threshold[$order])) {
            print "Discarding: order=$order, " . abs($cur[$order])
                . " > $threshold[$order]\n" if $DEBUG;
            return ();
        }
    }
    print "Inside After:\n" if $DEBUG;
    print "\tOld=[" . (join ",", @old) . "]\n" if $DEBUG;
    print "\tCur=[" . (join ",", @cur) . "]\n" if $DEBUG;
    # print "" . (join ",", map { abs($_) } @cur[(1 .. $#cur)]) . "\n";

    return @cur;
}

# create brushes for erasers ; returns GDraw Brushes
sub getEraser {
    my $radius = shift;
    my $brush = new GD::Image($radius * 2, $radius * 2);
    my $transColor = $brush->colorAllocate(0, 255, 255); # scrap color
    my $bgColor = $brush->colorAllocate(@backgroundColorRgb);
    $brush->transparent($transColor);
    $brush->arc($radius, $radius, $radius * 2, $radius * 2, 0, 360, $bgColor);
    $brush->fill($radius, $radius, $bgColor);

    return $brush;
}

# converts points into X and way based on board extents and image size
sub translate {
    my $x = shift;
    my $y = shift;
    my @coords = ();
    push @coords, int (($x - $leftX) / ($rightX - $leftX) * $width);
    push @coords, int (($y - $topY) / ($bottomY - $topY) * $height);
    return @coords;
}

sub savePage {
    my $file = "$sessionDir/page-$curPage-shot-$curShot.png";
    # ALT my $file = (join '-', @threshold) . ".png";
    open PNGFILE, ">$file"
        || die "Couldn't write to png snapshot '$file': $!\n";
    binmode PNGFILE;
    # $board->string(gdSmallFont, 0, 0, $file, $pens{'BLACK'}); # ALT
    print PNGFILE $board->png;
    close PNGFILE;
    $curShot++;
    return $file;
}

# call this whenever the "page is turned"
sub newPage {
    # create the data dir and session dir
    unless (-e $dataDir && -w _ && -r _) {
        mkdir $dataDir || die "Unable to create data directory: $dataDir\n";
    }
    $sessionDir = "$dataDir/mimio-" . time2str("%Y-%m-%d-%H-%M", $^T);
    unless (-e $sessionDir && -w _ && -r _) {
        mkdir $sessionDir || die "Unable to create session: $sessionDir\n";
    }

    $curPage++;
    $curShot = 1;

    open LOGFILE, ">$sessionDir/page-$curPage.script"
        || die "Couldn't open script: $!.\n";

    $board = new GD::Image($width, $height);
    $board->colorAllocate(@backgroundColorRgb);
    $pens{'BLACK'} = $board->colorAllocate(0, 0, 0);
    $pens{'RED'} = $board->colorAllocate(255, 0, 0);
    $pens{'GREEN'} = $board->colorAllocate(0, 255, 0);
    $pens{'BLUE'} = $board->colorAllocate(0, 0, 255);
}


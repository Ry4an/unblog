#!/usr/bin/perl -w

# Fast-prototyped reverse-engineered debugging decoder for protocol 
# used by Mimio digital whiteboard (http://www.mimio.com)

# by Keith Winstein, Adrian Birka, Jim Morash, and others at MIT French House
# <sipb-iap-dvd@mit.edu>

# Outputs noisy [no post-filtering] (x, y) on STDOUT, debugging junk on STDERR

# Copyright (C) 2000 Keith Winstein
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

$| = 1;

$debug = 0;

$h = 53; # distance between ultrasound receivers

use Device::SerialPort;

$mimio = new Device::SerialPort( "/dev/ttyS0" );

$mimio->baudrate( 19200 );
$mimio->parity( "none" );
$mimio->databits( 8 );
$mimio->stopbits( 1 );

sub transform {
  my ($a, $b) = @_;

  print STDERR "($a, $b)" if $debug;

  $a = ($a - 630) / 144;
  $b = ($b - 630) / 144;

  my ($x, $y) = (0, 0);

  eval {
    $x = sqrt( $a**2 - (($a**2 - $b**2 + $h**2)**2) / (4 * $h**2) );
    $y = - ( $a**2 - $b**2 + $h**2 ) / (2 * $h);
  };

  $x = int( 100 * $x ) / 100;
  $y = int( 100 * $y ) / 100;

  print STDERR " <$x, $y>" if $debug;

  return ($x, $y);
}

sub tobinbyte {
  my $in = shift;
  my $out = "00000000";
  
  die "Too big: $in\n" if ($in > 255);
  
  for (0 .. 7) {
    substr( $out, 7 - $_, 1 ) = "1" if ($in & 2**$_);
  }
  
  return $out;
}

sub tobinword {
  my $in = shift;
  my $out = "0000000000000000";
  
  die "Too big: $in\n" if ($in > 65535);
  
  for (0 .. 15) {
    substr( $out, 15 - $_, 1 ) = "1" if ($in & 2**$_);
  }
  
  return $out;
}

sub mimioread {
  my $count = 0;
  my $data;
  until( $count ) {
    ( $count, $data ) = $mimio->read( 1 );
  }
  
  return ord $data;
}

sub mimioreadn {
  my $total_read = 0;
  my $wanted_length = shift;
  my @mimiobytes;

  until ( $total_read == $wanted_length ) {
    push @mimiobytes, mimioread;
    $total_read++;
  }

  return join(" ", @mimiobytes);
}

%buttoncode = ( 291 => 'NEW',
		544 => 'TAG',
		1062 => 'PRINT',
		2090 => 'MAXIMIZE',
		4146 =>  'CALCULATOR');

%markercode = ( 1 => "BLACK",
		2 => "BLUE",
		3 => "GREEN",
		4 => "RED",
		9 => "BIGERASE",
		10 => "SMALLERASE" );

$currbyte = 0;

PACKET: while ( 1 ) {
  # find start-of-packet
  $sync_gap = 0;
  while ( $currbyte != 22 ) {
    $sync_gap++;
    $currbyte = mimioread;
  }

  unless( $sync_gap ) {
    print STDERR "\nPACKETSTART " if $debug;
  } else {
    print STDERR "\nRESYNC ($sync_gap) PACKETSTART " if $debug;
  }

  # better be 202 107 215 99 1 2
  
  if ( ($magicstring = mimioreadn(6)) eq "202 107 215 99 1 2" ) {
    print STDERR "_ " if $debug;
  } else {
    print STDERR "! ($magicstring) " if $debug;
    $currbyte = 0;
    next PACKET;
  }
  
  MINI: while( 1 ) {
    $currbyte = mimioread;

    if ( $currbyte == 50 ) { # TEMP
      $y = mimioread;
      $z = mimioread;
      print STDERR "TEMP ($y $z) " if $debug;
    } elsif ( $currbyte == 34 ) { # BUTTON
      print STDERR "BUTTON " if $debug;
      $y = mimioread;
      $z = mimioread;
      $button = $buttoncode{ $y * 256 + $z };
      if ( ! defined( $button ) ) {
	print STDERR "Un-known button: ($y $z)\n";
	$currbyte = 0;
	next PACKET;
      }
      print STDERR "($button) " if $debug;
      print "BUTTON $button\n";
      exit if ($button eq 'CALCULATOR');
    } elsif ( $currbyte == 22 ) {
      next PACKET;
    } elsif ( $currbyte == 40 ) { # MARKERSTART
      print STDERR "\nMARKERSTART " if $debug;

      $markercode = mimioread;
      $colorcode = $markercode{ $markercode };
      if ( ! defined( $colorcode ) ) {
	$colorcode = $markercode{ $markercode - 128 };
	if ( ! defined( $colorcode ) ) {
	  print STDERR "Unknown marker code: ( $markercode )\n";
	  $currbyte = 0;
	  next PACKET;
	}
      }
      $markerstring = mimioreadn( 7 );

      print STDERR "($colorcode)\t\t[$markerstring] " if $debug;
      print "MARKERSTART $colorcode\n";
    } elsif ( $currbyte == 21 ) { # MARKER
      print STDERR "\nMARKER         " if $debug;

      $markerstring = mimioreadn( 5 );
      print STDERR "\t\t\t[$markerstring] " if $debug;
      $markx1 = (split / /, $markerstring)[0];
      $markx2 = (split / /, $markerstring)[1];
      $marky1 = (split / /, $markerstring)[2];
      $marky2 = (split / /, $markerstring)[3];

      $markx = 256 * $markx1 + $markx2;
      $marky = 256 * $marky1 + $marky2;
      if ($markx * $marky) {
	($x, $y) = transform( $markx, $marky );
	print STDERR "$x $y\n" if $debug;
      }
      print "MARK $x $y\n";
    } elsif ( $currbyte == 24 ) { # MARKEXTEND
      print STDERR "\nMARKEXTEND " if $debug;
      
      $markercode = mimioread;
      $colorcode = $markercode{ $markercode };
      $lowbattery = 0;
      if ( ! defined( $colorcode ) ) {
	$colorcode = $markercode{ $markercode - 128 };
        $lowbattery = 1;
	if ( ! defined( $colorcode ) ) {
	  print STDERR
            "Unknown color: ( $markercode [lowbattery = $lowbattery])\n";
	  $currbyte = 0;
	  next PACKET;
	}
      }
      $markerstring = mimioreadn( 7 );
      print STDERR "($colorcode)\t\t[$markerstring] " if $debug;
      $markx1 = (split / /, $markerstring)[0];
      $markx2 = (split / /, $markerstring)[1];
      $marky1 = (split / /, $markerstring)[2];
      $marky2 = (split / /, $markerstring)[3];

      $markx = 256 * $markx1 + $markx2;
      $marky = 256 * $marky1 + $marky2;
      if ($markx * $marky) {
	($x, $y) = transform( $markx, $marky );
	print STDERR "$x $y\n" if $debug;
      }
      print "MARKEXTEND $x $y $colorcode\n";
    } elsif ( $currbyte == 18 ) {
      print STDERR "\nMARKEND " if $debug;
      $x = mimioreadn 2;
      print STDERR "$x\n" if $debug;
      print "MARKEND\n";
    } else {
      print STDERR "\n!! MINICODE: ($currbyte)\n";
      $currbyte = 0;
      next PACKET;
    }
  }

  print STDERR "\n!!!\n" if $debug;
  $currbyte = 0;
}

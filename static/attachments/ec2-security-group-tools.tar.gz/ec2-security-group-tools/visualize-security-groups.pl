#!/usr/bin/perl -w

# Take the tab separated outptu of ec2-decribe-group and emits a visualization
# of group to group access.
#
# Example usage:
#   ec2-describe-group | ./visualize-security-groups > output.png

use strict;
use diagnostics;

use GraphViz;

my $g = GraphViz->new(); # ratio => 8/11);

my %seen_groups = ();
my %seen_edges = ();

while (<>) {
    chomp;
    my ($type, @cols) = split "\t";

    next unless ($type eq 'PERMISSION');

    my ($owner, $name, $allows, $protocol, $port_start, $port_end, $from_to,
        $principle_type) = @cols;

    next unless ($principle_type eq 'USER');

    my ($group_owner, $name_pair) = @cols[8,9];

    my $group;
    (($group) = ($name_pair =~ /^NAME\s+(\S+)$/))
        or die "Bad group name '$name_pair'\n";

    &maybe_add_node($name);
    &maybe_add_node($group);

    &maybe_add_edge($group, $name, "$protocol $port_start");
}

print $g->as_png;

sub maybe_add_node {
    my $group_name = shift;
    return if $seen_groups{$group_name};
    $g->add_node($group_name);
    $seen_groups{$group_name}++;
}

sub maybe_add_edge {
    my ($from, $to, $label) = @_;
    my $key = "$from $to";
    return if $seen_edges{$key};
    $g->add_edge($from => $to, label => $label);
    $seen_edges{$key}++;
}

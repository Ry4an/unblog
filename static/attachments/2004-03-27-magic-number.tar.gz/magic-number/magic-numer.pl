#!/usr/bin/perl

$| = 1;     # turn off buffering
unlink "input.txt";

while (1) {
    print "";
    sleep 1;
    next unless (-e "input.txt");
    open INFILE, "<input.txt";
    chomp ($_ = <INFILE>);
    close INFILE;
    unlink "input.txt";
    last if (/quit/);
    if (/TAB/) {   # for convenience, \t also works
	print "\x08";
	next;
    }
    unless (/NUM/) {
	print "$_\x0D";
	next;
    }
    open NUMLIST, "<numberlist";
    unlink "progress";
    until (-e "input.txt") {
	sleep 1;
	chomp($_ = <NUMLIST>);
	print "$_\x0D";
	open PROGRESS, ">>progress";
	print PROGRESS "$i\n" if ($i++ % 100 == 0);
	close PROGRESS;
    }
}






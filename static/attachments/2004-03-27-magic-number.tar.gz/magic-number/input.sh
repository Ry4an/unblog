#!/bin/sh
echo -e "$*" > input.txt

#!/usr/bin/perl -w

# This script is placed in the public domain by Ry4an Brase http://ry4an.org

use strict;
use Date::Manip;

my ($date, $id, $received) = ();
my %entries = ();

while (<>) {
    chomp;
    if (/^Date:\s*(.*?)\s*$/) {
        $date = $1;
        #print "date: id=$id, date=$date, received=$received\n";
    }
    if (/^In-Reply-To:\s*<([^>]+)>/) {
        $id = $1;
        #print "IRT: date: id=$id, date=$date, received=$received\n";
    }
    if (/^On (.* at [^,]*), .* wrote:\s*$/) {
        $received = $1;
        #print "On: date: id=$id, date=$date, received=$received\n";
    }
    if (defined $id && defined $date && defined $received) {
        unless (exists $entries{$id}) {
            print "id=$id, date=$date, received=$received\n";
            $entries{$id} = [$date, $received];
        }
        $date = $id = $received = undef;
    }
    if (/^From /) {
        $date = $id = $received = undef;
    }
}

my %histogram = ();

my ($count, $total) = (0,0);

foreach (values %entries) {
    my ($outStr, $inStr) = @{$_};
    my $inTime = &ParseDate($inStr);
    my $outTime = &ParseDate($outStr);
    my $respTime = &DateCalc($inTime, $outTime, \$_);
    my $minDelay = int &Delta_Format($respTime, 0, '%mt');
    my $secDelay = int &Delta_Format($respTime, 0, '%st');
    if ($minDelay < 0) {
        next;
    }
    $count++;
    $total += $secDelay;
    $histogram{$minDelay}++;
}

open PLOT, "| gnuplot" || die "Couldn't run Gnuplot.";
print PLOT "set output \"email-response-times.png\"\n";
print PLOT "set terminal png small color \n";
print PLOT "set ylabel \"Quantity \"\n";
print PLOT "set xlabel \"Delay in Minutes\"\n";
print PLOT "set logscale x\n";
print PLOT "set nokey\n";
print PLOT qq|plot "-" with points\n|;

foreach my $minutes (sort { $a <=> $b} keys %histogram) {
    print PLOT "$minutes, $histogram{$minutes}\n";
}

close PLOT;

print "Output is in email-response-times.png\n";
print "Average response time in seconds: ", (int ($total/$count)), "\n";


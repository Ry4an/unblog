package org.ry4an.pokertimer;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;

public class PokerTimer extends JFrame {

    private boolean initted = false;
    private boolean paused = false;
    private long remainingWhilePaused;

    private static final double[] MULTIPLIERS = {1.0, 2.0, 4.0, 8.0, 15.0,
        30.0, 60.0};

    double initialSmallBlind;
    private JLabel smallBlindLabel;
    private JLabel bigBlindLabel;
    private JLabel smallBetLabel;
    private JLabel bigBetLabel;
    private JLabel roundLabel;
    private JProgressBar meter;

    private int millisPerRound;
    private int round = 0;
    private long endOfRound;

    public PokerTimer(int mpr, double sb) {
        super("PokerTimer");
        initialSmallBlind = sb;
        millisPerRound = mpr;
    }

    public void init() {
        synchronized (this) {
            if (initted) {
                throw new IllegalStateException("Already initted");
            }
            initted = true;
        }
        setBounds(0, 0, 1020, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container content = getContentPane();
        Font big = new Font(content.getFont().getFontName(), Font.BOLD, 70);
        content.setLayout(new GridLayout(5, 2));
        content.add(new JLabel("SMALL BLIND")).setFont(big);
        content.add(smallBlindLabel = new JLabel("--")).setFont(big);
        content.add(new JLabel("BIG BLIND")).setFont(big);
        content.add(bigBlindLabel = new JLabel("--")).setFont(big);
        content.add(new JLabel("EARLY BET")).setFont(big);
        content.add(smallBetLabel = new JLabel("--")).setFont(big);
        content.add(new JLabel("LATE BET")).setFont(big);
        content.add(bigBetLabel = new JLabel("--")).setFont(big);
        content.add(roundLabel = new JLabel("ROUND 0")).setFont(big);
        content.add(meter = new JProgressBar(0, millisPerRound));
        meter.setFont(big);
        meter.setValue(0);
        meter.setStringPainted(true);
        addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent ke) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        PokerTimer.this.pause();
                    }
                });
            }
        });
        show();
    }

    public void update() {
        if (paused) {
            return;
        }
        long now = System.currentTimeMillis();
        if (endOfRound < now) { // finished a round
            double smallBlind = initialSmallBlind
                * Math.pow(10.0, 2*(round/MULTIPLIERS.length))
                * MULTIPLIERS[round % MULTIPLIERS.length];
            round++;
            smallBlindLabel.setText("$" + (int)smallBlind);
            bigBlindLabel.setText("$" + (int)smallBlind * 2);
            smallBetLabel.setText("$" + (int)smallBlind * 2);
            bigBetLabel.setText("$" + (int)smallBlind * 4);
            endOfRound = now + millisPerRound;
            roundLabel.setText("ROUND " + round);
        }
        long remaining = endOfRound - now;
        int minsLeft = (int)(remaining / 60 / 1000);
        int secsLeft = (int)(remaining / 1000 % 60);
        meter.setString(minsLeft + ((secsLeft < 10)?":0":":") + secsLeft);
        meter.setValue((int)(millisPerRound - remaining));
    }

    public void pause() {
        long now = System.currentTimeMillis();
        if (paused) { // unpause
            endOfRound = now + remainingWhilePaused;
        } else { // pause
            meter.setString("PAUSED");
            remainingWhilePaused = endOfRound - now;
        }
        paused = !paused;
    }

    public void start() {
        (new Timer()).schedule(new TimerTask() {
            public void run() {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        update();
                    }
                });
            }
        }, 1000, 1000);
    }

    public static void main(String[] args) {
        System.out.println("Usage: PokerTimer [minutes per round] "
            + " [initial small blind dollars]");
        double mins = 20.0;
        try {
            mins = Double.parseDouble(args[0]);
        } catch (Exception ignored) {
        }
        double sb = 1.0;
        try {
            sb = Double.parseDouble(args[1]);
        } catch (Exception ignored) {
        }
        PokerTimer pt=new PokerTimer((int)(1000.0 * 60.0 * mins), sb);
        pt.init();
        pt.start();
        synchronized (pt) {
            try {
                pt.wait(); // don't exit
            } catch (InterruptedException ignored) {
            }
        }
    }
}

// vim: nofen

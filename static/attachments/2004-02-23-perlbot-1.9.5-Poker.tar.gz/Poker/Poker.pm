package Perlbot::Plugin::Poker;

# TODO side pots, enforce min bet/raise size, check or evaluator suit ranking,
#       add dollar signs

use DB_File;
use Perlbot::Plugin;
use strict;
use Games::Poker::TexasHold'em; # supid class name '
use Games::Cards;
use Games::Poker::HandEvaluator qw(handval evaluate);
use String::Approx qw(amatch);

our @ISA = qw(Perlbot::Plugin);

our $VERSION = '1.0.0';

sub init {
  my $self = shift;

  $self->want_fork(0);
  $self->want_action(1);

  $self->{big_blind} = $self->config->value(poker => 'big_blind');
  # How many seconds a player can hold up the game
  $self->{max_delay} = $self->config->value(poker => 'max_delay');
  $self->{game} = undef;
  $self->{waiting_to_join} = []; # joined mid game
  $self->{last_raiser} = 'BUG'; # the person who's gonna have to show on call
  $self->{next_action} = (); # record in advance what a player wants to do
  $self->{check_call_count} = 0; # for knowing when the round is _really_ done
  $self->{starting_funds} = $self->config->value(poker => 'starting_funds');

  tie %{$self->{accounts}}, 'DB_File', File::Spec->catfile($self->{directory},
    'accounts'), O_CREAT|O_RDWR, 0640, $DB_HASH; # nick to bankroll

  $self->{players} = [];

  $self->hook_event('public', \&handle_public);
  $self->hook_event('msg', \&handle);
  $self->hook_event('caction', \&handle);
}

# global commands like deal, kill-player, etc.
sub handle_public {
  my $self = shift;
  my $event = shift;
  # $event->dump;
  my $nick = $event->nick;
  my @args = ($event->args);
  my $msg = shift @args;
  my $resp;

  $self->{channel} = $event->{to}[0] unless defined $self->{channel};

  if ($msg =~ /^deal$/i) {
    if (defined $self->{game} && $self->{game}->stage ne 'showdown') {
      $self->addressed_reply("There's already a hand in progress.");
      return;
    }
    my @players = @{$self->{players}};
    foreach my $joiner (@{$self->{waiting_to_join}}) {
      next if (grep /$joiner/, @players);  # skip people already in the game
      if (@players > 2) {
        push @players, $joiner;
      } else { # insert into 3rd position
        # insert any new joins two positions from the front (big blind payer)
        splice @players, 2, 0, $joiner;
      }
    }
    $self->{waiting_to_join} = [];
    $self->{players} = [@players];
    if (scalar @{$self->{players}} < 2) {
      $self->addressed_reply("At least two players must have joined the game.");
      return;
    }
    $self->new_game;
    $self->update;
    return;
  }

  # nag the pending player
  if ($msg =~ /^nag$/i) {
    if (!(defined $self->{game}) || $self->{game}->stage eq 'showdown') {
      $self->addressed_reply('the game is still forming.');
      return;
    }
    $self->addressed_reply('okay, I nagged ' . $self->{game}->next_to_play);
    $self->perlbot->msg($self->{game}->next_to_play,
      "People are waiting on you in the poker game on channel "
        . $self->{channel});
    return;
  }

  # status
  if ($msg =~ /^status$/i) {
    if (defined $self->{game} && $self->{game}->stage ne 'showdown') {
      $self->reply(split "\n", $self->{game}->status);
    } else {
      $self->reply("No status currently available");
    }
    return;
  }

  # for forcing players out
  if ($msg =~ /^eject$/i) {
    if (!(defined $self->{game}) || $self->{game}->stage eq 'showdown') {
      $self->addressed_reply('the game is still forming.');
      return;
    }
    if ($self->{last_action_time} + $self->{max_delay} > time) {
      $self->addressed_reply("you haven't been waiting more than "
        . $self->{max_delay} . ' seconds yet.');
      return;
    }
    my $on_deck = $self->{game}->next_to_play;
    $self->addressed_reply("okay, I ejected $on_deck");
    $self->{next_action}->{$on_deck} = "fold";
    my @players = grep !/^$on_deck$/, @{$self->{players}};
    $self->{players} = [@players];
    $self->update;
    return;
  }

}

sub _match {
  return amatch(shift, ["i"], @_);
}

# this will accept all the player specific actions via msg or actions
sub handle {
  my $self = shift;
  my $event = shift;
  # $event->dump;
  my $nick = $event->nick;
  my $msg;
  my $resp;
  my @args = ($event->args);
  if ($event->type eq 'caction') {
    shift @args;
    $msg = join " ", @args;
  } else { # msg
    $msg = shift @args;
  }

  my ($word, $qty);
  # TODO add "jumped the gun" scolding
  if (&_match('joins', $msg)) { # handle joining
    # skip people already in the game
    my @players = @{$self->{players}};
    unless (grep /$nick/, (@players, @{$self->{waiting_to_join}})) {
      push @{$self->{waiting_to_join}}, $nick;
      $resp = "you're on the list for the next hand.";
    } else {
      $resp = "you're already on the list";
    }
  } elsif (&_match('leaves', $msg)) { # handle quitting
    # remove from @players and @waiting_to_join and fold
    my @joiners = grep !/^$nick$/, @{$self->{waiting_to_join}};
    $self->{waiting_to_join} = [@joiners];
    my @players = grep !/^$nick$/, @{$self->{players}};
    $self->{players} = [@players];
    $self->{next_action}->{$nick} = 'fold';
  } elsif (!(defined $self->{game})) { # all actions below this require a game
    $resp = "No game has yet been started."
  } elsif (&_match('shows', $msg) || &_match('reveals', $msg)) { # show cards
    if ($self->{game}->stage ne 'showdown') {
      $resp = "You can't show your cards before the showdown."
    } else {
      $self->_say("$nick (unnecessarily) reveals "
        . &_hand_to_str($self->{cards}->get_cardset_by_name($nick)));
    }
  } elsif (&_match('peeks', $msg)) { # handle peeks (to see own blind)
    $self->perlbot->msg($nick, "Your hole cards "
      . (($self->{game}->stage eq 'showdown')?"were: ":"are: ")
      . &_hand_to_str($self->{cards}->get_cardset_by_name($nick)));
  } elsif (&_match('status', $msg)) { # handle status
    $self->reply(split "\n", $self->{game}->status);
  } elsif (&_match('folds', $msg)) { # handle fold
    $self->{next_action}->{$nick} = 'fold';
  } elsif (&_match('checks', $msg)) { # handle check
    $self->{next_action}->{$nick} = 'check';
  } elsif (&_match('all in', $msg)) { # all in
    $self->{next_action}->{$nick} = "bet " . $self->{game}->bankroll($nick);
  } elsif (&_match('calls', $msg)) { # handle call
    $self->{next_action}->{$nick} = 'call';
  } elsif ((($word, $qty) = $msg =~ /(\w+)\s+(\d+)/) # handle bet
      && &_match('bets', $word)) {
    $self->{next_action}->{$nick} = "bet $qty";
  } elsif ((($word, $qty) = $msg =~ /(\w+)\s+(\d+)/) # handle raise
      && &_match('raises', $word)) {
    $self->{next_action}->{$nick} = "raise $qty";
  } elsif ($event->type eq 'msg') { # only error on private messages
    $resp = "I'm sorry, but I don't know what '$msg' means."
  }

  # output
  if (defined $resp) {
    if ($event->type eq 'caction') {
      $self->addressed_reply($resp);
    } else {
      $self->reply($resp);
    }
  }

  if (defined $self->{game} && $self->{game}->stage ne 'showdown'
      && $nick eq $self->{game}->next_to_play) {
    $self->update;
  }
}

# checks for next action and advances game as necessary
sub update {
  my $self = shift;

  while (1) {
    while ($self->maybe_advance) { # advance as many as possible
      return if $self->maybe_showdown;
    }
    unless ($self->maybe_action) {
      my $msg = $self->{game}->next_to_play
        . ", action is to you. Current bet is "
        . $self->{game}->{current_bet} . ".";
      if ($self->{game}->{current_bet}) {
        $msg .= " You need " . ($self->{game}->{current_bet}
        - $self->{game}->{players}->[$self->{game}->{next}]->{in_this_round})
        . " to call.";
      }
      $self->_say($msg);
      return;
    }
    $self->{last_action_time} = time;
  }
}

# takes action if available
sub maybe_action {
  my $self = shift;

  my $position = $self->{game}->{next};
  my $short = $self->{game}->{current_bet}
    - $self->{game}->{players}->[$position]->{in_this_round};
  my $who = $self->{game}->next_to_play;
  my $bankroll = $self->{game}->bankroll($who);

  # get cached action if any
  my $action = delete $self->{next_action}->{$who};

  # TODO check for players without enough money to act (those in side pots)
  
  unless (defined $action) {
    return 0;
  }

  if ($action eq 'fold') {
    $self->_say("$who folds.\n");
    $self->{game}->fold;
    return 1;
  }

  if ($action eq 'check') {
    if ($short) {
      $self->reply("$who, you can't check, you need $short to call.");
      return 0;
    } else {
      $self->_say("$who checks.\n");
    }
    $self->{game}->check_call;
    $self->{check_call_count}++; # another person says it's okay to move on
    return 1;
  }

  if ($action eq 'call') {
    if ($short) {
      $self->_say("$who pays $short to call.\n");
    } else {
      $self->_say("$who checks.\n");
    }
    $self->{game}->check_call;
    $self->{check_call_count}++; # another person says it's okay to move on
    return 1;
  }

  my $bet;
  unless (($action, $bet) = $action =~ '(\w+)\s+(\d+)') {
    $self->_say("BUG: unparsable values action: $action\n");
    return 0;
  }

  if ($action eq 'raise') {
    $bet += $short;
    $action = 'bet';
  }

  if ($action eq 'bet') {

    if ($bet > $bankroll) {
      $self->reply("$who, you don't have $bet left.\n");
      return 0;
    }

    if ($bet < $short) {
      $self->reply("$who, $bet isn't sufficient to call "
        . $self->{game}->{current_bet} .  ".\n");
      return 0;
    }

    if ($bet == $short) {  # really a call
      $self->_say("$who pays $short to call.\n");
      $self->{game}->check_call;
      $self->{check_call_count}++;  # another person says it's okay to move on
      return 1;
    }

    # TODO check for minimum bet/raise

    $self->{game}->bet_raise($bet);
    $self->{last_raiser} = $who;
    $self->{check_call_count} = 1; # reset okay-to-move-on counter
    if ($self->{game}->{current_bet} == $bet) {
      $self->_say("$who bets $bet.\n");
    } else {
      $self->_say("$who raises " . ($bet - $short) . " to "
        . $self->{game}->{current_bet} .  ".\n");
    }
    return 1;
  }

  $self->_say("BUG: unknown action: $action\n");
  return 0;
}

sub maybe_showdown {
  my $self = shift;

  return 0 unless ($self->{game}->stage eq 'showdown');
  $self->do_showdown;
  return 1;
}

sub do_showdown {
  my $self = shift;

  # flush (pre-payoff) bankroll balances
  foreach my $nick ($self->{game}->players) {
    $self->{accounts}->{$nick} = $self->{game}->bankroll($nick);
  }

  # determine winner
  my $bestHandVal = -1;
  my @winners;
  my $active_count = 0;
  foreach my $nick ($self->{game}->players) {
    next if ($self->{game}->folded($nick));
    $active_count++;
    my $boardCpy = $self->{cards}->get_cardset_by_name('Board')
      ->clone($self->{cards}, "boardcpy");
    my $hand = $self->{cards}->get_cardset_by_name($nick)
      ->clone($self->{cards}, "$nick-both");
    while ($boardCpy->give_a_card($hand, 0)) { }
    my $handVal = evaluate($hand);
    if ($handVal == $bestHandVal) { # ties
      push @winners, $nick;
    } elsif ($handVal > $bestHandVal) { # new best
      $bestHandVal = $handVal;
      @winners = ($nick);
    }
  }

  # announce winner
  if ($active_count == 1) { # every one else folded
    $self->_say("$winners[0] won because everyone else folded.\n");
  } else { # more than 1 person still in
    # display last raiser's cards
    unless ($self->{game}->folded($self->{last_raiser})) {
      $self->_say($self->{last_raiser} . " has been called and shows: " .
        &_hand_to_str($self->{cards}->get_cardset_by_name($self
          ->{last_raiser})));
    }
  }
  
  if (@winners > 1) {
    my @victors = ();
    foreach my $nick (my @winners) {
      push @victors, "$nick ("
        . &_hand_to_str($self->{cards}->get_cardset_by_name($nick)) . ")";
    }
    $self->_say((join " and ", @victors) . " split the win (and "
      . $self->{game}->pot . ") with " . handval($bestHandVal) .  "\n");
  } elsif (@winners == 1) {  # single winner
    if ($active_count == 1) { # only 1 player left
      $self->_say("$winners[0] wins " . $self->{game}->pot . ".");
    } else { # multiple winners
      $self->_say("$winners[0] shows "
        . &_hand_to_str($self->{cards}->get_cardset_by_name($winners[0]))
        . " and wins " . $self->{game}->pot . " with " . handval($bestHandVal)
        . "\n");
    }
  }

  # award winning pot
  foreach my $nick (@winners) {
    $self->{accounts}->{$nick} += int ($self->{game}->pot / @winners);
  }

  # move first player to last position
  my @players = @{$self->{players}};
  push @players, shift @players;
  $self->{players} = [@players];
}

sub _hand_to_str {
  my $hand = shift;
  my $cardStr = $hand->print();
  $cardStr =~ s/^\w+:\s*//;
  $cardStr =~ s/\s+/ /g;
  $cardStr =~ s/\s*$//g;
  return $cardStr;
}

# makes sure pot is right and that everyone has raised, checked, or called
sub maybe_advance {
  my $self = shift;

  return 0 unless ($self->{game}->pot_square);

  # check $self->{check_call_count} to make sure everyone's gotten a turn
  my $active_count = 0;
  foreach my $nick ($self->{game}->players) {
    next if ($self->{game}->folded($nick));
    $active_count++;
  }
  return 0 unless ($active_count<2 || $active_count==$self->{check_call_count});
  $self->{check_call_count} = 0;

  $self->do_advance;
  return 1;
}

sub do_advance {
  my $self = shift;

  # flip up cards if applicable
  my $cards_to_add = 0;
  if ($self->{game}->stage eq 'preflop') {
    $cards_to_add = 3;
  } elsif ($self->{game}->stage eq 'flop') {
    $cards_to_add = 1;
  } elsif ($self->{game}->stage eq 'turn') {
    $cards_to_add = 1;
  }
  if ($cards_to_add) {
    $self->{cards}->get_cardset_by_name('Deck')
      ->give_cards($self->{cards}->get_cardset_by_name('Board'),
      $cards_to_add);
    # announce new cards
    $self->_say("Board now shows: "
      . &_hand_to_str($self->{cards}->get_cardset_by_name('Board')) . "\n");
  }

  $self->{game}->next_stage;  # we're not using their internal board array
}

sub new_game {
  my $self = shift;

  if (defined $self->{game} && $self->{game}->stage ne 'showdown') {
    warn "starting a new game while game in progress";
  }
  $self->{next_action} = (); # zero out pre-actions
  my @thePlayers = ();
  foreach my $nick (@{$self->{players}}) {
    unless (defined $self->{accounts}->{$nick}) {
      $self->{accounts}->{$nick} = $self->{starting_funds};
    }
    push @thePlayers, {name=>$nick, bankroll=>$self->{accounts}->{$nick}};
  }
  $self->{game} = new Games::Poker::TexasHold'em( # stupid class name '
    players=>\@thePlayers,
    button=>@{$self->{players}}[0],
    bet=>$self->{big_blind}, limit=>0,
  );
  $self->{game}->_advance; # they do the button wrong
  $self->_say($self->{game}->next_to_play
    . " pays the small blind (" . ($self->{big_blind}/2) .  ")\n");
  $self->{game}->_advance; # they do the button wrong
  $self->_say($self->{game}->next_to_play
    . " pays the big blind ($self->{big_blind})\n");
  $self->{last_raiser} = $self->{game}->next_to_play; # paid big blind
  $self->{game}->_advance; # they do the button wrong

    
  $self->{cards} = new Games::Cards::Game;  # tracks all card related actions
  Games::Cards::Deck->new($self->{cards}, 'Deck'); # create the deck
  Games::Cards::Hand->new($self->{cards}, 'Board'); # face up cards

  $self->{cards}->get_cardset_by_name("Deck")->shuffle;

  # give hole cards
  foreach my $position (0 .. $self->{game}->players-1) {
    my $hand = new Games::Cards::Hand($self->{cards},
      $self->{game}->seat2name($position));

    $self->{cards}->get_cardset_by_name("Deck")->give_cards($hand, 2);

    # tells players their hole cards
    $self->perlbot->msg($self->{game}->seat2name($position), 
      "Your hole cards are: " . &_hand_to_str($hand));
  }

  $self->{game}->blinds;
}

sub _say {
  my $self = shift;
  my $msg = shift;
  chomp $msg;

  $self->perlbot->msg($self->{channel}, $msg);
}

# vim: sw=2

1;

#!/usr/bin/perl -w

# Requires garble (http://freshmeat.net/projects/garble/) format waypoint and
# track data to be found in the currentw working directory in files named
# 'waypoints' and 'tracks', respectively.  You must have gnuplot installed.

# This code is released into the public domain by Ry4an Brase http://ry4an.org

# Based on an idea by Dave Pearson http://www.davep.org/misc/#garble-track-plot

use strict;

my @y1 = ();
my @y2 = ();
my @x1 = ();
my @x2 = ();

open PLOT, "|gnuplot" || die "couldn't run gnuplot: $!";
print PLOT "set output \"chart.png\"\n";
print PLOT "set terminal png small color \n";

open WAYPOINTS, "<waypoints" || die $!;
my ($name, $lat, $lon);
foreach (<WAYPOINTS>) {
    chomp;
    unless (($name, $lat, $lon) = m[^(\w+) / (\S+), (\S+) /]) {
        print "Skipping '$_'\n";
        next;
    }
    print PLOT "set label \"$name\" at $lon, $lat\n";
    print "waypoint: lat: $lat, lon: $lon\n";
}
close WAYPOINTS;

print PLOT "plot \"-\" title \"tracks\" with lines\n";

open ROUTE, "<tracks" || die $!;
foreach (<ROUTE>) {
    chomp;
    unless (($lat, $lon) = m[(\S+), (\S+) /]) {
        print "Skipping '$_'\n";
        next;
    }
    print PLOT "$lon $lat\n";
    print "route: lat: $lat, lon: $lon\n";
}
close ROUTE;
close PLOT;

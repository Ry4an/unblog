#!/usr/bin/perl -w
# Ry4an Brase http://ry4an.org places this in the public domain.

use strict;

my $adj = 3600 * -11;

my $line = '';

while (<>) {
    if (s/\x0d\x0a$//) {
        $line .= "$_; ";
        next;
    }
    chomp;
    $line .= $_;
    my @cols = split /\|/s, $line;
    shift @cols;  # kill spurious first column

    map s/^\s*(.*?)\s*$/$1/, @cols;  # .trim() all 

    my ($start, $end, $title, $desc, $location, $isPrivate) =
        ("".gmtime $cols[5]+$adj, "".gmtime $cols[7]+$adj, $cols[11], $cols[12],
        $cols[13], ($cols[10] == 1)?"false":"true");

    print "------------\n";
    print "Title=$cols[11]\n";
    print "Start=$start\n";
    print "End=$end\n";
    print "Description=$desc\n" if $desc;
    print "Location=$location\n" if $location;
    print "isPrivate=$isPrivate\n";
    $line = '';
}

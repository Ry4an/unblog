#!/usr/bin/perl -w
# Ry4an Brase http://ry4an.org places this in the public domain.

use strict;
use Date::Format;
use Date::Parse;
use DateTime;
use DateTime::TimeZone;

my $tz = DateTime::TimeZone->new( name => 'America/Chicago' );

my $adj = 3600 * -6;


my $HEADER = "BEGIN:VCALENDAR\nVERSION\n :2.0\nPRODID\n :-//ry4an.org/Groupware Conversion Calendar V1.0//EN\n";

my $FORMAT_DATE = "%Y%m%d";
my $FORMAT_TIME = "T%H%M%S";

my $line = '';

print $HEADER;
my $id = "000000000000";
while (<>) {
    if (s/(.*)\x0d\x0a$//) {
        $line .= "$1\\n";
        next;
    }
    chomp;
    $line .= $_;
    my @cols = split /\|/s, $line;
    shift @cols;  # kill spurious first column

    map s/^\s*(.*?)\s*$/$1/, @cols;  # .trim() all 

    my $tzAdj = $tz->offset_for_datetime(DateTime
        ->from_epoch(epoch=>$cols[5]));
    $cols[5] += $adj + $tzAdj;
    $cols[7] += $adj + $tzAdj;

    my ($start, $end, $title, $desc, $location, $class, $created) =
        ($cols[5], $cols[7], $cols[11], $cols[12],
        $cols[13], ($cols[10] == 1)?"PUBLIC":"PRIVATE", $cols[6]);
    $title =~ s/([;,])/\\$1/g;
    $desc =~ s/([;,])/\\$1/g;
    $location =~ s/([;,])/\\$1/g;

    # repair and old phpgroupware workaround
    my $when = time2str("%R", $end, "GMT");
    if ("23:59" eq time2str("%R", $end, "GMT")) {
        $end += 60;
    }

    print "BEGIN:VEVENT\nUID:\n :5343869c-1dd2-11b2-be5e-$id\n";
    print "SUMMARY\n :$title\n";
    print "DESCRIPTION\n :$desc\n" if $desc;
    print "LOCATION\n :$location\n" if $location;
    print "STATUS\n :CONFIRMED\n";
    print "CLASS\n :$class\n";
    if ($start != $end) {
        print "DTSTART\n :", time2str($FORMAT_DATE, $start, "GMT"),
            time2str($FORMAT_TIME, $start, "GMT"), "\n";
        print "DTEND\n :", time2str($FORMAT_DATE, $end, "GMT"),
            time2str($FORMAT_TIME, $end, "GMT"), "\n";
    } else {  # whole day events
        print "DTSTART\n :", time2str($FORMAT_DATE, $start, "GMT"), "\n";
        print "DTEND\n :", time2str($FORMAT_DATE, $end + 24*3600, "GMT"), "\n";
    }
    print "DTSTAMP\n :", time2str($FORMAT_DATE, $created, "GMT"),
        time2str($FORMAT_TIME, $created, "GMT"), "Z\n";
    print "END:VEVENT\n";
    
    $line = '';
    $id++;
}
print "END:VCALENDAR\n";

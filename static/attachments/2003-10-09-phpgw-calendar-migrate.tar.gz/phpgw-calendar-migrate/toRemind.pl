#!/usr/bin/perl -w
# Ry4an Brase http://ry4an.org places this in the public domain.

use strict;
use Date::Format;
use Date::Parse;

# REM 5 March 1999 AT 13:00 DURATION 1:30 MSG Meeting

my $adj = 3600 * -11;
my $DAY = 3600 * 24;

my $line = '';

print "# vim: syntax=remind\n\n";
while (<>) {
    if (s/\x0d\x0a$//) {
        $line .= "$_; ";
        next;
    }
    chomp;
    $line .= $_;
    my @cols = split /\|/s, $line;
    shift @cols;  # kill spurious first column

    map s/^\s*(.*?)\s*$/$1/, @cols;  # .trim() all 

    $cols[5] += $adj; # timezones
    $cols[7] += $adj; # timezones

    if ($cols[5] < $^T) {  # skip items in the past
        $line = '';
        next;
    }

    my ($start, $end, $title, $desc, $location, $isPrivate) =
        ("".gmtime $cols[5], "".gmtime $cols[7], $cols[11], $cols[12],
        $cols[13], ($cols[10] == 1)?"false":"true");

    my $days = int ($cols[7]/$DAY)-int($cols[5]/$DAY);
    foreach my $day (0 .. $days) {
        print time2str("REM %d %B %Y", $cols[5] + ($day * $DAY), "GMT");
        if ($day == 0) { # only show start time on first day
            print time2str(" AT %R", $cols[5], "GMT");
        }
        if ($days == 0) { # one day event
            print time2str(" DURATION %R", $cols[7] - $cols[5], "GMT");
        }

        print " MSG %\"$title%\"";
        if ($day == 0) { # only show start time on first day
            print " %2";
        }
        print "%_Location: $location" if $location;
        print "%_$desc" if $desc;
        print "\n";
    }

    $line = '';
}

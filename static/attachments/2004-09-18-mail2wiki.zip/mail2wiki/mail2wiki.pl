#!/usr/bin/perl -w

# Takes an email as input and appends it to a wiki page
# Released into the public domain by Ry4an Brase - http://ry4an.org

use strict;
use LWP::UserAgent;
use HTTP::Request::Common qw(POST);
use HTTP::Cookies;

my $body = "";
my $page;
my $title = 'Untitled';
my $from = 'Unknown';
my $isBody = 0;
my $urlBase = 'http://somewhere.com/wiki';
my $cookieFile = '/home/user/somwhere/cookies.txt';

while (<>) {
    if ($isBody) {
        $body .= $_;
        next;
    }
    if (/wiki-(\w+)\@/) {
        $page = $1;
        next;
    }
    if (/^Subject:\s*(.*?)\s*$/) {
        $title = $1;
        next;
    }
    if (/^From:\s*(.*?)\s*$/) {
        $from = $1;
        next;
    }
    $isBody = 1 if (/^\s*$/);
}
unless ($page) {
    print STDERR "No email address specifying page found\n";
    exit;
}

my $ua = LWP::UserAgent->new;
$ua->cookie_jar(HTTP::Cookies->new('file' => $cookieFile));


my $req = HTTP::Request->new(GET
    => "$urlBase/$page?action=edit");
my $res = $ua->request($req);

unless ($res->is_success) {
    print STDERR "Unable to fetch wiki page '$page': $!\n";
    exit;
}

my ($when, $oldBody);

if ($res->content =~ /<input type="hidden" name="datestamp" value="(\d+)">/s) {
    $when = $1;
} else {
    print STDERR "Unable to extract datestamp from edit page.\n";
    exit;
}

if ($res->content =~ /<textarea [^>]*>(.*)<\/textarea>/s) {
    $oldBody = $1;
    if ($oldBody eq "Describe $page here.") {
        $oldBody = "";
    }
} else {
    print STDERR "Unable to extract old body from edit page: ", $res->content;
    exit;
}

while ($oldBody =~ s/&amp;/&/g) {}
while ($oldBody =~ s/&gt;/>/g) {}
while ($oldBody =~ s/&lt;/</g) {}

$req = POST "$urlBase/$page",
    [ 'action' => 'savepage', 'datestamp' => $when,
        'button_save' => 'Save Changes', 'notify' => 1,
        'comment' => 'gatewayed from email', 'savetext' =>
        "$oldBody\n== $title ==\nPosted " . localtime()
            . " by $from\n{{{\n$body\n}}}\n"];
$res = $ua->request($req);

unless ($res->is_success) {
    print STDERR "Unable to update wiki page '$page': $!\n";
    exit;
}

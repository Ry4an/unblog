#!/usr/bin/perl

use HTTP::Cookies;

$jar = HTTP::Cookies->new;

$jar->set_cookie($version, 'MOIN_ID', '#############.#####', '/wiki', 'somewhere.com', '80', 1, 0, 3600*24*365*10, 0);

$jar->save("/home/user/somwhere/cookies.txt");

#!/usr/bin/perl -w

use strict;

my @dice;
my $pos = 0;

# setup dice
foreach my $a (1 .. 6) {
    foreach my $b (1 .. 6) {
        foreach my $c (1 .. 6) {
            foreach my $d (1 .. 6) {
                foreach my $e (1 .. 6) {
                    foreach my $f (1 .. 6) {
                        $dice[$pos++] = [$f, $e, $d, $c, $b, $a];
                         #print "dice[" . ($pos-1) . "]: (" . (join ',',
                         #   @{$dice[$pos-1]}) . ")\n";
                    }
                }
            }
        }
    }
}

print STDERR "Attack Dice,Attack Bonus,Defend Dice,Defend Bonus,Win,Tie,Loss\n";

foreach my $attack_dice (2 .. 3) {
    foreach my $attack_bonus (0 .. 1) {
        foreach my $defend_dice (1 .. 3) {
            foreach my $defend_bonus (0 .. 1) {
                &test ($attack_dice, $defend_dice, $attack_bonus,$defend_bonus);
            }
        }
    }
}


################ subroutines ##########################

sub test {
    my ($attack_qty, $defend_qty, $attack_bonus, $defend_bonus) = @_;
    print "Attacking Dice: $attack_qty, Attacking Bonus: $attack_bonus, "
        . "Defending Dice: $defend_qty, Defending Bonus: $defend_bonus\n";
    print STDERR "$attack_qty,$attack_bonus,$defend_qty,$defend_bonus,";

    my $test_qty = 6**($attack_qty + $defend_qty);
    my ($wins, $losses, $ties) = (0,0,0);
    foreach my $roll (0 .. $test_qty-1) {
        my $result = &battle($roll, @_);
        if ($result == 1) {
            $wins++;
        } elsif ($result == 0) {
            $ties++;
        } elsif ($result == -1) {
            $losses++;
        } else {
            die "bug!";
        }
    }
    print "\tWin%:" . ($wins/$test_qty*100) . ", Tie%:" . ($ties/$test_qty*100)
        . ", Loss%:" . ($losses/$test_qty*100) . "\n";
    print STDERR (join ',', (($wins/$test_qty), ($ties/$test_qty), ($losses/$test_qty))) . "\n";
}

sub battle {
    my ($roll, $attack_qty, $defend_qty, $attack_bonus, $defend_bonus) = @_;

    my $attack_total = $attack_bonus + &max(@{$dice[$roll]}[0..$attack_qty-1]);
    my $defend_total = $defend_bonus
        + &max(@{$dice[$roll]}[$attack_qty .. $attack_qty + $defend_qty - 1]);
    my $result = $attack_total <=> $defend_total;
    #print "$attack_total vs. $defend_total => $result\n";
    return $result;
}

sub max {
    my $val = 0;
    foreach (@_) {
        if ($_ > $val) {
            $val = $_;
        }
    }
    # print "Max: (" . (join ',', @_) . ") => $val\n";
    return $val;
}

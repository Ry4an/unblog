# This perlbot plugin gateways an IRC chump bot to a phpwiki.  See the
# accompanying README file for configuration details.
#
# This script is placed in the public domain by Ry4an Brase http://ry4an.org/


package WikiChump::Plugin;

use HTTP::Request::Common qw(POST);
use HTML::Form;
use HTTP::Cookies;
use LWP::UserAgent;

my $wikiUrl = 'http://www.host.org/phpwiki/index.php/WikiChump';

my %wikiName = ('Ry4an' => 'RyFouranBrase',
    'another' => 'SomeoneElse');

sub get_hooks {
    return { public => \&public };
}

sub public {
    my ($conn, $event) = @_;

    my $message = ($event->args)[0];

    my $chan = ($event->to)[0];

    my $who = $event->from;
    $who =~ s/\!.*//;
    if (defined $wikiName{$who}) {
        $who = $wikiName{$who}  
    } else {
        $who = "<$who>";
    }

    my ($url, $letter, $comment);

    if ($message =~ /^([A-Z])\:\s*(\S.*?)\s*$/) {
        $letter = $1;
        $comment = $2;
    } elsif ($message =~ /(https?:\/\/\S+?)[,.]*(\s|$)/) {
        $url = $1;
    } else {
        return; # don't bother forking
    }

    if (!defined($pid = fork)) {
        $conn->privmsg($chan, "error in WikiChump...");
        return;
    }

    if ($pid) {
        # parent
        $SIG{CHLD} = sub { wait; };
        return;
    } else {
        # child...

        my $ua = LWP::UserAgent->new;
        $ua->agent("WikiChump ");

        if (-e "$ENV{'HOME'}/.cookies.txt" && -r _) {
            $ua->cookie_jar(HTTP::Cookies->new('file'
                => "$ENV{'HOME'}/.cookies.txt"));
        }

        my $req = POST $wikiUrl, [ action => 'edit' ];

        my $res = $ua->request($req);

        # check for error
        $conn->privmsg($chan, "can't get edit page") unless $res->is_success();

        my @forms = HTML::Form->parse($res->as_string, $res->base());
        $conn->privmsg($chan, "can't parse edit page") unless (@forms);
        my $form = $forms[1]; # the first one is title search

        my $editBox = $form->find_input('edit[content]');
        $conn->privmsg($chan, "can't find edit box") unless (defined $editBox);

        my $minor = $form->find_input('edit[minor_edit]');

        my $oldContent = $editBox->value;
        
        my $newContent;
        ##############################
        if (defined $url) {
            $newContent = &handle_url($conn, $chan, $who, $oldContent,$url);
            $minor->value(undef);
            my $summary = $form->find_input('edit[summary]');
            $summary->value("added $url");
        } elsif (defined $letter) {
            $newContent = &handle_comment($conn, $chan, $who, $oldContent,
                $letter, $comment);
            $minor->value('on');
        } else {
            $conn->privmsg($chan, "impossible situation in WikiChump...");
        }
        #############################

        if (defined $newContent) {
            $editBox->value($newContent);
            $req = $form->click('edit[save]');
            $res = $ua->request($req);

            # check for error
            $conn->privmsg($chan, "Error submitting") unless $res->is_success();
        }

        $conn->{_connected} = 0;
        exit 0;  # kill child
    }
}

sub handle_url {
    my ($conn, $chan, $who, $oldContent, $url) = @_;

    my @old = split /[\r\n]+/, $oldContent;
    my $letter;
    my $newMsg = "";
    while (my $line = shift @old) {  # find the unparsable header
        chomp $line;
        $newMsg .= "$line\n";
        if ($line =~ /^----\s*$/) {
            last;
        }
    }
    unless (@old) {  # we went all the way through it?
        $conn->privmsg($chan, "Malformed page. Tell Ry4an");
        return undef;
    }
    my $line = $old[0];  #the next line should be an entry header
    unless ($line =~ /^([A-Z]): \[(.*?)\|(.*?)\] posted by (.*?) at (.*?)\s*$/){
        $conn->privmsg($chan, "Unable to parse '$line'.  Tell Ry4an.");
        return undef;
    }
    my $letter = $1;
    $letter++;
    $letter = 'A' if ($letter eq 'AA');  # wrap around

    $newMsg .= "$letter: [$url|$url] posted by $who at " . localtime() . "\n";
    $newMsg .= "----\n";

    $newMsg .= join "\n", @old;

    $conn->privmsg($chan, "$letter: $url from $who"); # better after HTTP POST
    return $newMsg;
}

sub handle_comment {
    my ($conn, $chan, $who, $oldContent, $letter, $comment) = @_;
    my $isTitle = 0;

    if (substr($comment, 0, 1) eq '|') {
        $isTitle = 1;
        substr($comment, 0, 1) = '';
    }

    my @old = split /[\r\n]+/, $oldContent;
    my $newMsg = "";
    my $line;
    my ($url, $author, $when);
    while ($line = shift @old) {  # find the unparsable header
        chomp $line;
        if ($line =~ /^$letter: \[(.*?)\|(.*?)\] posted by (.*?) at (.*?)\s*$/){
            $url = $2;
            $author = $3;
            $when = $4;
            last;
        }
        $newMsg .= "$line\n";
    }

    # check for item not found
    unless (@old) {  # we went all the way through it?
        $conn->privmsg($chan, "Item $letter not found.");
        return undef;
    }

    if ($isTitle) {
        $newMsg .= "$letter: [$comment|$url] posted by $author at $when\n";
        $conn->privmsg($chan, "titled item $letter"); # better after POST
    } else {  # is a comment
        $newMsg .= "$line\n";
        $newMsg .= "* $who: $comment\n";
        $conn->privmsg($chan, "commented item $letter"); # better after POST
    }

    $newMsg .= join "\n", @old;

    return $newMsg;
}

sub unimport {
}

1;

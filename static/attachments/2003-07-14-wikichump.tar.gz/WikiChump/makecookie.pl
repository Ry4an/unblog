#!/usr/bin/perl

# this script can be run from the commandline to create the auto-wiki login
# cokie necessary to have wikichump edits show up under the WikiChump user.
# It's not necessary.  Make sure you run this script as whatever user the bot
# will run as the $HOME environment variable is used to locate the cookies.txt
# file.

use HTTP::Cookies;

$jar = HTTP::Cookies->new;

# This value is most easily found by logging into the wiki as WikiChump using
# your webbrowser, then exiting your web browser and opening up your browser's
# cookies file.  Steal the value from the WIKI_PREFS2 cookie.
my $value = 'O%3A15%3A%22userpreferences%22%3A1%3A%7Bs%3A6%3A%22_prefs%22%3Ba%3A3%3A%7Bs%3A10%3A%22editHeight%22%3Bi%3A22%3Bs%3A9%3A%22editWidth%22%3Bi%3A80%3Bs%3A6%3A%22userid%22%3Bs%3A9%3A%22WikiChump%22%3B%7D%7D';

my $wikiDomain = 'www.host.org';

$jar->set_cookie($version, 'WIKI_PREFS2', $value, '/', $wikiDomain, '80',
    1, 0, 3600*24*365*10, 0);

$jar->save($ENV{'HOME'} . "/.cookies.txt");
